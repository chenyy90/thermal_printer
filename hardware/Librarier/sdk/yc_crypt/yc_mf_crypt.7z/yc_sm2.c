#include "yc_sm2.h"
#include "../sdk/yc_rand.h"
#include "yc_calc.h"

//#define SM2_DEBUG
//函数名称：my_KDF
//函数功能：实现国密SM2加解密算法中的密钥派生函数kdf
//输入参数： Z      -用于计算的数据串（二进制值）
//          zlen   -内容长度
//          klen   -需要派生得到的长度
//输出参数： K      -计算后返回的内容（二进制值）,分配空间至少为需要keylen
//返回值：RET_SM2_KDF_SUCCESS表示成功，RET_SM2_KDF_FAILURE表示失败
uint32_t SM2_KDF(uint8_t *K, uint32_t klen,  uint8_t *Z, uint32_t zlen)
{
    uint8_t cdgst[32]={0}; //摘要
    uint8_t cCnt[4] = {0}; //计数器的内存表示值
    int nCnt  = 1;  //计数器
    int nDgst = 32;//摘要长度

    int nTimes = (klen+31)/32; //需要计算的次数
    int i = 0;
	int j = 0;

    for(i=0; i<nTimes; i++,nCnt ++)
    {
        {
            cCnt[0] =  (nCnt>>24) & 0xFF;
            cCnt[1] =  (nCnt>>16) & 0xFF;
            cCnt[2] =  (nCnt>> 8) & 0xFF;
            cCnt[3] =  (nCnt    ) & 0xFF;
        }
		for(j = 0; j < zlen; j++)
		{
			SM3_BYTE(NULL, Z[j],j,0);
		}
		for(j = 0; j < 3; j++)
		{
			SM3_BYTE(NULL, cCnt[j],zlen+j,0);
		}
		SM3_BYTE(cdgst, cCnt[3],zlen+3,1);

		if(K == NULL)
		{
			return RET_SM2_KDF_FAILURE;
		}
        if(i == nTimes-1)//最后一次计算，根据keylen/32是否整除，截取摘要的值
        {
            if(klen%32 != 0)
            {
                nDgst = klen%32;
            }
        }
		memcpy(K+32*i,cdgst,nDgst);
    }

	j = 0;
	for(i = 0; i < klen; i++)
	{
		if(0 == K[i])
		{
			j++;
		}
	}

	if(j == klen)
	{
		return RET_SM2_KDF_FAILURE;
	}
    return RET_SM2_KDF_SUCCESS;
}

static uint32_t init_para(ecc_para *para_t,uint32_t *p_c,uint32_t *n_c,uint32_t *n1_c,SM2_EllipseParaTypeDef *para,uint32_t config,uint32_t a_type)
{
	uint32_t i,ret;

	para_t->p = para->p;
	para_t->a = para->a;
	para_t->b = para->b;
	para_t->g.x = para->g.x;
	para_t->g.y = para->g.y;
	para_t->n = para->n;
	
	para_t->p_c = p_c;
	para_t->n_c = n_c;
	para_t->n1_c = n1_c;

	para_t->a_type = a_type;
	ecc_config(para_t,config);

//	ecc_config(para_t,ECC_P256);
//	calc_const_c(para_t->n_c, para_t->n,para_t->len_words);
//	calc_const_q(&(para_t->n_q), para_t->n);

#ifdef SM2_DEBUG
		MyPrintf("para_t:\n");
	MyPrintf("para_t.p:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",para_t->p[i]);	MyPrintf("\n");
	MyPrintf("para_def.a:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",para_t->a[i]);	MyPrintf("\n");
	MyPrintf("para_def.b:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",para_t->b[i]);	MyPrintf("\n");
	MyPrintf("para_def.g.x:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",para_t->g.x[i]);	MyPrintf("\n");
	MyPrintf("para_def.g.y:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",para_t->g.y[i]);	MyPrintf("\n");
	MyPrintf("para_def.n:\n");
	for(i=0;i<8;i++)
		MyPrintf("%08x ",para_t->n[i]);	MyPrintf("\n");

	MyPrintf("para_def.p_c:\n");
	for(i=0;i<para_t->len_words;i++)
		MyPrintf("%08x ",para_t->p_c[i]);	MyPrintf("\n");
	MyPrintf("para_def.p_q:\n");
	MyPrintf("%08x ",para_t->p_q);	MyPrintf("\n");		
	MyPrintf("para_def.n_c:\n");
	for(i=0;i<para_t->len_words;i++)
		MyPrintf("%08x ",para_t->n_c[i]);	MyPrintf("\n");
	MyPrintf("para_def.n_q:\n");
	MyPrintf("%08x ",para_t->n_q);	MyPrintf("\n");
#endif
	return 0;
}

void mem_reverse(uint32_t *data_temp,uint32_t *data,uint32_t len)
{
	uint32_t i;
	for(i=0;i<len;i++)
	{
		data_temp[i] =((data[len-i-1]>>24)&0xff) +((data[len-i-1]>>8)&0xff00) +  ((data[len-i-1]<<8)&0xff0000) + ((data[len-i-1]<<24)&0xff000000);		
	}
}

// static void memcpy_r(uint8_t *a,uint8_t *b,uint32_t len)
// {
// 	uint32_t i;
// 	uint8_t temp[MAX_RSA_MODULUS_BITS]={0};
// 	for(i=0;i<len;i++)
// 		temp[i] = b[len-1-i];
// 	for(i=0;i<len;i++)
// 		a[i] = temp[i];
// }

// uint32_t SM2_Hash_Za(uint8_t *Za, uint8_t *IDa, uint16_t IDalen, SM2_EllipseParaTypeDef *para, SM2_PublicKeyTypeDef *key, uint16_t block_size)
// {
// 	uint8_t data_temp[256]={0};
// 	uint16_t index = 0;
// 	uint16_t i=0;
// 	uint8_t *pdata;
// 	uint8_t data_1[64];

// 	data_temp[0] = (IDalen>>8);
// 	data_temp[1] = IDalen;

// 	mem_rollcpy_char(&data_temp[2], IDa, IDalen/8,GetTRNGData());
// 	index = 2+IDalen/8;

// 	pdata = (uint8_t *)(para->a);
// 	pdata += block_size;
// 	for (i=0;i<block_size;i++)
// 	{
// 		data_1[i] = *(pdata-i-1);
// 	}
// 	mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
// 	index += block_size;

// 	pdata = (uint8_t *)(para->b);
// 	pdata += block_size;
// 	for (i=0;i<block_size;i++)
// 	{
// 		data_1[i] = *(pdata-i-1);
// 	}
// 	mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
// 	index += block_size;

// 	pdata = (uint8_t *)(para->g.x);
// 	pdata += block_size;
// 	for (i=0;i<block_size;i++)
// 	{
// 		data_1[i] = *(pdata-i-1);
// 	}
// 	mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
// 	index += block_size;

// 	pdata = (uint8_t *)(para->g.y);
// 	pdata += block_size;
// 	for (i=0;i<block_size;i++)
// 	{
// 		data_1[i] = *(pdata-i-1);
// 	}
// 	mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
// 	index += block_size;

// 	pdata = (uint8_t *)(key->x);
// 	pdata += block_size;
// 	for (i=0;i<block_size;i++)
// 	{
// 		data_1[i] = *(pdata-i-1);
// 	}
// 	mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
// 	index += block_size;

// 	pdata = (uint8_t *)(key->y);
// 	pdata += block_size;
// 	for (i=0;i<block_size;i++)
// 	{
// 		data_1[i] = *(pdata-i-1);
// 	}
// 	mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
// 	index += block_size;

// #ifdef SM2_DEBUG	
// 	MyPrintf("data_temp:\n");
// 	for(i=0;i<index;i++)
// 		MyPrintf("%02x ",data_temp[i]);	MyPrintf("\n");
// #endif
// 	return SM3(Za,(uint8_t *)data_temp,index);  
	
// }

uint32_t SM2_Hash_Za(uint8_t *Za, uint8_t *IDa, uint16_t IDalen, SM2_EllipseParaTypeDef *para, SM2_PublicKeyTypeDef *key, uint16_t block_size)
{
	uint8_t data_temp[256]={0};
	uint16_t index = 0;
	uint16_t i=0;
	uint8_t *pdata;
//	uint8_t data_1[64];
#ifdef SM2_DEBUG
	MyPrintf("SM2_Hash_Za :block_size=%d\n",block_size);
#endif

	data_temp[0] = (IDalen>>8);
	data_temp[1] = IDalen;

	SM3_BYTE(NULL, data_temp[0],0,0);
	SM3_BYTE(NULL, data_temp[1],1,0);
	index += 2;

#ifdef SM2_DEBUG
	MyPrintf("%02x ",data_temp[0]);
	MyPrintf("%02x ",data_temp[1]);
#endif
	#ifdef SM2_DEBUG
			MyPrintf("\n");
	#endif
	// mem_rollcpy_char(&data_temp[2], IDa, IDalen/8,GetTRNGData());
	// index = 2+IDalen/8;
	//Ida
	if(IDalen % 8)
	{
		goto SM2_Hash_Za_ERR;
	}
	for(i = 0;i < IDalen/8; i++)
	{
		SM3_BYTE(NULL, IDa[i],index++,0);
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",IDa[i]);
		#endif
	}
	#ifdef SM2_DEBUG
			MyPrintf("\n");
	#endif

	// pdata = (uint8_t *)(para->a);
	// pdata += block_size;
	// for (i=0;i<block_size;i++)
	// {
	// 	data_1[i] = *(pdata-i-1);
	// }
	// mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
	// index += block_size;
	pdata = (uint8_t *)(para->a);
	pdata += block_size;
	for (i=0;i<block_size;i++)
	{
		SM3_BYTE(NULL, *(pdata-i-1),index++,0);
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*(pdata-i-1));
		#endif
	}
	#ifdef SM2_DEBUG
			MyPrintf("\n");
	#endif


	// pdata = (uint8_t *)(para->b);
	// pdata += block_size;
	// for (i=0;i<block_size;i++)
	// {
	// 	data_1[i] = *(pdata-i-1);
	// }
	// mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
	// index += block_size;
	pdata = (uint8_t *)(para->b);
	pdata += block_size;
	for (i=0;i<block_size;i++)
	{
		SM3_BYTE(NULL, *(pdata-i-1),index++,0);
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*(pdata-i-1));
		#endif
	}
	#ifdef SM2_DEBUG
			MyPrintf("\n");
	#endif

	// pdata = (uint8_t *)(para->g.x);
	// pdata += block_size;
	// for (i=0;i<block_size;i++)
	// {
	// 	data_1[i] = *(pdata-i-1);
	// }
	// mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
	// index += block_size;
	pdata = (uint8_t *)(para->g.x);
	pdata += block_size;
	for (i=0;i<block_size;i++)
	{
		SM3_BYTE(NULL, *(pdata-i-1),index++,0);
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*(pdata-i-1));
		#endif
	}
	#ifdef SM2_DEBUG
			MyPrintf("\n");
	#endif

	// pdata = (uint8_t *)(para->g.y);
	// pdata += block_size;
	// for (i=0;i<block_size;i++)
	// {
	// 	data_1[i] = *(pdata-i-1);
	// }
	// mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
	// index += block_size;
	pdata = (uint8_t *)(para->g.y);
	pdata += block_size;
	for (i=0;i<block_size;i++)
	{
		SM3_BYTE(NULL, *(pdata-i-1),index++,0);
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*(pdata-i-1));
		#endif
	}
	#ifdef SM2_DEBUG
			MyPrintf("\n");
	#endif
	// pdata = (uint8_t *)(key->x);
	// pdata += block_size;
	// for (i=0;i<block_size;i++)
	// {
	// 	data_1[i] = *(pdata-i-1);
	// }
	// mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
	// index += block_size;
	pdata = (uint8_t *)(key->x);
	pdata += block_size;
	for (i=0;i<block_size;i++)
	{
		SM3_BYTE(NULL, *(pdata-i-1),index++,0);
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*(pdata-i-1));
		#endif
	}
	#ifdef SM2_DEBUG
			MyPrintf("\n");
	#endif

	// pdata = (uint8_t *)(key->y);
	// pdata += block_size;
	// for (i=0;i<block_size;i++)
	// {
	// 	data_1[i] = *(pdata-i-1);
	// }
	// mem_rollcpy_char((data_temp+index), data_1, block_size,GetTRNGData());
	// index += block_size;
	pdata = (uint8_t *)(key->y);
	pdata += block_size;
	for (i=0;i<block_size - 1;i++)
	{
		SM3_BYTE(NULL, *(pdata-i-1),index++,0);
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*(pdata-i-1));
		#endif
	}
	SM3_BYTE(Za, *(pdata-i-1),index++,1);
	#ifdef SM2_DEBUG
			MyPrintf("%02x ",*(pdata-i-1));
	#endif
	#ifdef SM2_DEBUG
			MyPrintf("\n");
	#endif
	if(index != (block_size * 6 + 2 + IDalen/8))
	{
		#ifdef SM2_DEBUG
			MyPrintf("index=%d - (block_size * 6 + 2 + IDalen/8)=%d\n",index,(block_size * 6 + 2 + IDalen/8));
		#endif
		goto SM2_Hash_Za_ERR;
	}
	return RET_SM3_SUCCESS;
//	return SM3(Za,(uint8_t *)data_temp,index);

SM2_Hash_Za_ERR:
	memset(Za,0,32);
	return RET_SM3_FAILE;
}

uint32_t SM2_Hash_z(uint8_t *Za, uint8_t *IDa, uint16_t IDalen, SM2_EllipseParaTypeDef *para, SM2_PublicKeyTypeDef *key)
{
	uint32_t i;
	uint32_t data_temp[5+8+8+8+8+8+8]={0};

	data_temp[0] = ((IDalen<<8)&0xff00)+((IDalen&0xff00)>>8);
	memcpy(((uint8_t *)data_temp)+2,IDa,18);
	mem_reverse((uint32_t *)(data_temp+5),(para->a),8);
	mem_reverse((uint32_t *)(data_temp+5+8),(para->b),8);
	mem_reverse((uint32_t *)(data_temp+5+8+8), (para->g.x),8);
	mem_reverse((uint32_t *)(data_temp+5+8+8+8),(para->g.y),8);
	mem_reverse((uint32_t *)(data_temp+5+8+8+8+8),(key->x),8);
	mem_reverse((uint32_t *)(data_temp+5+8+8+8+8+8),(key->y),8);
#ifdef SM2_DEBUG
	MyPrintf("data_temp:\n");
	for(i=0;i<((2+18+32+32+32+32+32+32)>>2);i++)
		MyPrintf("%08x ",data_temp[i]);	MyPrintf("\n");
#endif
	return SM3(Za,(uint8_t *)data_temp,2+18+32+32+32+32+32+32);

}

uint32_t SM2_Hash_e(uint32_t *e, uint8_t *Za, uint8_t *m, uint32_t mlen)
{
	uint32_t i;
	uint32_t index = 0;
	uint32_t data_temp[16]={0};

//	memcpy(((uint8_t *)data_temp),Za,32);
//	memcpy(((uint8_t *)data_temp)+32,m,mlen);
	#ifdef SM2_DEBUG
			MyPrintf("\nSM2_Hash_e:\n");
	#endif

	#ifdef SM2_DEBUG
			MyPrintf("za:\n");
	#endif
	for(i = 0;i<32;i++)
	{
		SM3_BYTE(NULL, Za[i],index++,0);
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",Za[i]);
		#endif
	}

	#ifdef SM2_DEBUG
			MyPrintf("\nmessage:\n");
	#endif
	for(i = 0;i<mlen-1;i++)
	{
		SM3_BYTE(NULL, m[i],index++,0);
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",m[i]);
		#endif
	}
	SM3_BYTE((uint8_t*)e, m[mlen-1],index++,1);
	#ifdef SM2_DEBUG
			MyPrintf("%02x ",m[mlen-1]);
	#endif

//	 SM3((uint8_t *)e,(uint8_t *)data_temp,32+mlen);
	memcpy_r((uint8_t *)e,(uint8_t *)e,32);
	return 0;
}

uint32_t SM2_DigitalSignWith_e(SM2_SignTypeDef *sign, uint32_t *e,
							uint8_t *msg, uint32_t mlen,
							SM2_PrivateKeyTypeDef *key, SM2_EllipseParaTypeDef *para,
							rng_callback f_rng, void *p_rng, uint8_t config)
{
	uint32_t i,ret;
	calc_operand operand;
	uint32_t *pdata;
	
	//uint32_t k[11]={0x1FB2F96F,0x260DBAAE,0xDD72B727,0xC176D925,0x4817663F,0x94F94E93,0x385C175C,0x6CB28D99,0};
	//uint32_t k[9]={0xada186d6,0x5399b341,0x98158c60,0x97703d64,0x46d454c3,0x7a8a7b4a,0x8e24b735,0x36cd79fc,0};
	uint32_t k[11] = {0};
	SM2_PointTypeDef c1 = {0};
	ecc_point_a c1_p = {0};
	uint32_t data_temp[9]={0};
	
	ecc_security security_t = {0};
	ecc_para para_t = {0};
	uint32_t p_c[9]={0},n_c[9]={0},n1_c[9]={0};	

	uint32_t zero[9]={0};
	uint32_t rand_data[2];

	uint32_t sm2_flow_addval = 0;
	uint32_t sm2_flow_flag = 0;
	
	security_t.mask=INT_MASK_OPEN;
	security_t.verify=EC_PARA_VERIFY_OPEN;

	(*f_rng)((uint8_t *)rand_data,8,NULL);

	
	//(*f_rng)((uint8_t *)sm2_rand_val,32,NULL);


	init_para(&para_t, p_c, n_c,n1_c, para, config,  !ECC_A_IS_NEGATIVE_3);

get_rand:
	#ifdef BCTC
		for (i=0;i<9;i++)
		{
			k[i] = sm2_rand_val[i];
		}
	#else
		//(*f_rng)((uint8_t *)k,32,NULL);
		
		for (i=0;i<8;i++)
		{
			k[i] = GetTRNGData();
		}
	#endif
	
	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval = 0XAA;
		sm2_flow_flag = 1;
	#endif

	#ifdef SM2_FLOW_CONTROL
		sm2_flow_flag *= 0XAA;
		if ((sm2_flow_flag != 0XAA) || (sm2_flow_addval != 0XAA))
		{
			return RET_SM2_SIGN_FAILURE;
		}
	#endif

	#ifdef SM2_DEBUG
	MyPrintf("\nk_rand:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",k[i]);	MyPrintf("\n");
	MyPrintf("\n");

	MyPrintf("\nrand_add:\n");
	for(i=0;i<2;i++)
		MyPrintf("%08x ",rand_data[i]);	MyPrintf("\n");
	MyPrintf("\n");
	#endif
	
	ret = mem_cmp(k, zero, para_t.len_words);
	if (ret == EQUAL)
	{
		goto get_rand;
	}

	ret = mem_cmp(para->n, k, para_t.len_words);
	if (ret != BIGGER)
	{
		goto get_rand;
	}
	
	c1_p.x= c1.x;
	c1_p.y= c1.y;
	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval += 0XAA55;
	#endif
	
	ret = ecc_pmul(&c1_p,&(para_t.g), k,&para_t,&security_t,rand_data,2);
	if(ret != RET_ECC_POINT_SUCCESS)
		return RET_SM2_SIGN_FAILURE;

	#ifdef SM2_FLOW_CONTROL
		if ((sm2_flow_flag == 0XAA) || (sm2_flow_addval != (0XAA+0XAA55)))
		{
			sm2_flow_flag = 0XAA55;
		}
	#endif
	
#ifdef SM2_DEBUG
	MyPrintf("\nlen_words:");
    MyPrintf("%08x ",para_t.len_words);
 	MyPrintf("\n ecc_pmul_calc:%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);	

	MyPrintf("g:\n");
	MyPrintf("g.x:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",para_t.g.x[i]);	MyPrintf("\n");
	MyPrintf("g.y:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",para_t.g.y[i]);	MyPrintf("\n");
	
	MyPrintf("k:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",k[i]);	MyPrintf("\n");
	MyPrintf("c1:\n");
	MyPrintf("x:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",c1.x[i]);	MyPrintf("\n");
	MyPrintf("y:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",c1.y[i]);	MyPrintf("\n");
#endif

#ifdef SM2_DEBUG
	MyPrintf("e:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",e[i]);	MyPrintf("\n");

	pdata = para_t.n;
	MyPrintf("n:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",*pdata++);	MyPrintf("\n");

	MyPrintf("%02x ",para_t.len_words);	MyPrintf("\n");
#endif

	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval += 0X55AA;
		if ((sm2_flow_flag != 0XAA55) || (sm2_flow_addval != (0XAA+0XAA55+0X55AA)))
		{
			return RET_SM2_SIGN_FAILURE;
		}
		sm2_flow_flag = 0X55AA;
	#endif
	calc_modadd_1(sign->r, e, c1.x ,para_t.n , (para_t.len_words > 8)? para_t.len_words : 8);//r = (e + x1)mod n
#ifdef SM2_DEBUG
	MyPrintf("\nr:\n");
	for(i=0;i<8;i++)
		MyPrintf("%08x ",sign->r[i]);	MyPrintf("\n");
#endif

	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval += 0XAA66;
		if ((sm2_flow_flag != 0X55AA) || (sm2_flow_addval != (0XAA+0XAA55+0X55AA+0XAA66)))
		{
			return RET_SM2_SIGN_FAILURE;
		}

		sm2_flow_flag = 0XAA66;
	#endif

	ret = mem_rollcmp(sign->r, zero, para_t.len_words,GetTRNGData());
	if (ret == CMPOK)
	{
		goto get_rand;
	}

	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval += 0X55AA66;
		if ((sm2_flow_flag != 0XAA66) || (sm2_flow_addval != (0XAA+0XAA55+0X55AA+0XAA66+0X55AA66)))
		{
			return RET_SM2_SIGN_FAILURE;
		}
		sm2_flow_flag = 0X55AA66;
	#endif
	calc_add( data_temp, sign->r, k, para_t.len_words);
    ret = mem_rollcmp(data_temp, para->n, para_t.len_words,GetTRNGData());
	if (ret == CMPOK)
	{
		goto get_rand;
	}
	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval += 0X55AA77;
		if ((sm2_flow_flag != 0X55AA66) || (sm2_flow_addval != (0XAA+0XAA55+0X55AA+0XAA66+0X55AA66+0X55AA77)))
		{
			return RET_SM2_SIGN_FAILURE;
		}
		sm2_flow_flag = 0X55AA77;
	#endif
	calc_add( sign->s,key->d,(volatile uint32_t *)CONST_LONG_ONE, para_t.len_words);
	#ifdef SM2_DEBUG
	MyPrintf("\n  (1+da)\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",sign->s[i]);	MyPrintf("\n");
	#endif

	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval += 0XAA55AA;
		if ((sm2_flow_flag != 0X55AA77) || (sm2_flow_addval != (0XAA+0XAA55+0X55AA+0XAA66+0X55AA66+0X55AA77+0XAA55AA)))
		{
			return RET_SM2_SIGN_FAILURE;
		}
		sm2_flow_flag = 0XAA55AA;
	#endif
	ret = calc_modinv(sign->s, sign->s ,para_t.n , para_t.len_words); //  (1+da) ^ -1
#ifdef SM2_DEBUG

	MyPrintf("\n calc_modinv:%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);	

	MyPrintf("\n  (1+da) ^ -1 \n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",sign->s[i]);	MyPrintf("\n");
#endif	

	operand.a= sign->r;
	operand.b= key->d ;
	operand.p=(uint32_t *)para_t.n;
	operand.c=(uint32_t *)para_t.n_c;
	operand.q=para_t.n_q;

#ifdef SM2_DEBUG
	MyPrintf("\n  a: \n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",*(operand.a+i));	MyPrintf("\n");
	MyPrintf("\n  b: \n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",*(operand.b+i));	MyPrintf("\n");
	MyPrintf("\n  p: \n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",*(operand.p+i));	MyPrintf("\n");
	MyPrintf("\n  c: \n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",*(operand.c+i));	MyPrintf("\n");
	MyPrintf("\n  q: \n");
		MyPrintf("%08x ",operand.q);	MyPrintf("\n");
#endif

	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval += 0XAA55AA55;
		if ((sm2_flow_flag != 0XAA55AA) || (sm2_flow_addval != (0XAA+0XAA55+0X55AA+0XAA66+0X55AA66+0X55AA77+0XAA55AA+0XAA55AA55)))
		{
			return RET_SM2_SIGN_FAILURE;
		}
		sm2_flow_flag = 0XAA55AA55;
	#endif

	if(RET_CALC_IMPLEMENT_SUCCESS != calc_modmul_base(data_temp,&operand,para_t.len_words,0))
		return RET_SM2_SIGN_FAILURE;		
#ifdef SM2_DEBUG
	MyPrintf("\n  r* da mod n \n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",data_temp[i]);	MyPrintf("\n");
#endif	


	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval += 0XAA55AA66;
		if ((sm2_flow_flag != 0XAA55AA55) || (sm2_flow_addval != (0XAA+0XAA55+0X55AA+0XAA66+0X55AA66+0X55AA77+0XAA55AA+0XAA55AA55+0XAA55AA66)))
		{
			return RET_SM2_SIGN_FAILURE;
		}
		sm2_flow_flag = 0XAA55AA66;
	#endif
	calc_modsub(data_temp, k, data_temp, para_t.n, para_t.len_words) ;
	operand.a= sign->s;
	operand.b= data_temp ;
	operand.p=(uint32_t *)para_t.n;
	operand.c=(uint32_t *)para_t.n_c;
	operand.q=para_t.n_q;

	if(RET_CALC_IMPLEMENT_SUCCESS != calc_modmul_base(sign->s,&operand,para_t.len_words,0))
		return RET_SM2_SIGN_FAILURE;

	#ifdef SM2_FLOW_CONTROL
		sm2_flow_addval += 0XAA55AA77;
		if ((sm2_flow_flag != 0XAA55AA66) || (sm2_flow_addval != (0XAA+0XAA55+0X55AA+0XAA66+0X55AA66+0X55AA77+0XAA55AA+0XAA55AA55+0XAA55AA66+0XAA55AA77)))
		{
			return RET_SM2_SIGN_FAILURE;
		}
		sm2_flow_flag = 0XAA55AA77;
	#endif
	ret = mem_rollcmp(sign->s, zero, para_t.len_words,GetTRNGData());
	if (ret == CMPOK)
	{
		goto get_rand;
	}

#ifdef SM2_DEBUG
	MyPrintf("\n  s \n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",sign->s[i]);	MyPrintf("\n");
#endif	

	#ifdef SM2_FLOW_CONTROL
		if (sm2_flow_flag != 0XAA55AA77)
		{
			return RET_SM2_SIGN_FAILURE;
		}
	#endif
	
	return RET_SM2_SIGN_SUCCESS;
}

uint32_t SM2_VerifySignWith_e(SM2_SignTypeDef *sign, uint32_t *e,
							uint8_t *msg, uint32_t mlen,
							SM2_PublicKeyTypeDef *key, SM2_EllipseParaTypeDef *para,
							rng_callback f_rng, void *p_rng, uint8_t config)
{
		uint32_t i,ret;
	uint32_t z1[9],z2[9] = {0};
	calc_operand operand;
	SM2_PointTypeDef c1 = {0},c2 = {0};
	ecc_point_a c1_p,c2_p,pa;
	ecc_point_j j1,j2;
	uint32_t t[9]={0};
	
	ecc_security security_t = {0};
	ecc_para para_t;
	uint32_t p_c[9]={0},n_c[9]={0},n1_c[9]={0};	

	uint32_t zero[9]={0};

	uint8_t sm2_step = 1;
	uint32_t sm2_flow_flag = 0;

	sign->r[8] = 0;
	sign->s[8] = 0;
	
	security_t.mask=INT_MASK_OPEN;
	security_t.verify=EC_PARA_VERIFY_OPEN;
	sm2_step = 1;
	sm2_flow_flag = 1;

	init_para(&para_t, p_c, n_c, n1_c, para, config,  !ECC_A_IS_NEGATIVE_3);

	#ifdef SM2_FLOW_CONTROL
		sm2_flow_flag *= 49;
		if (sm2_flow_flag != 49)
		{
			return RET_SM2_VERIFY_FAILURE;
		}
	#endif

	ret = mem_rollcmp(sign->r, zero, para_t.len_words,GetTRNGData());
	if (ret == CMPOK)
	{
		return RET_SM2_VERIFY_FAILURE;
	}

	ret = mem_cmp(sign->r, para_t.n, para_t.len_words);
	if (ret != SMALLER)
	{
		return RET_SM2_VERIFY_FAILURE;
	}

	ret = mem_rollcmp(sign->s, zero, para_t.len_words,GetTRNGData());
	if (ret == CMPOK)
	{
		return RET_SM2_VERIFY_FAILURE;
	}

	ret = mem_cmp(sign->s, para_t.n, para_t.len_words);
	if (ret != SMALLER)
	{
		return RET_SM2_VERIFY_FAILURE;
	}
	#ifdef SM2_FLOW_CONTROL
		if (sm2_flow_flag != 49)
		{
			return RET_SM2_VERIFY_FAILURE;
		}
		sm2_flow_flag = 189;

		sm2_step = 2;
	#endif
	calc_modadd_1(t,sign->r,sign->s, para_t.n, para_t.len_words);
#ifdef SM2_DEBUG
	MyPrintf("\nlen_words:");
    MyPrintf("%08x ",para_t.len_words);

	MyPrintf("sign.r:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",sign->r[i]);	MyPrintf("\n");
	MyPrintf("sign.s:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",sign->s[i]);	MyPrintf("\n");
	
	MyPrintf("\n  t \n");
	for(i=0;i<8;i++)
		MyPrintf("%08x ",t[i]);	MyPrintf("\n");
#endif	

	ret = mem_rollcmp(t, zero, para_t.len_words,GetTRNGData());
	if (ret == CMPOK)
	{
		return RET_SM2_VERIFY_FAILURE;
	}

	#ifdef SM2_FLOW_CONTROL
		if (sm2_flow_flag != 189)
		{
			return RET_SM2_VERIFY_FAILURE;
		}
		sm2_flow_flag *= sm2_step;
		sm2_flow_flag += 11;
		sm2_step = 3;
	#endif

	c1_p.x= c1.x;
	c1_p.y= c1.y;
	ret = ecc_pmul(&c1_p,&(para_t.g), sign->s, &para_t,&security_t,NULL,0);
	if(ret != RET_ECC_POINT_SUCCESS)
		return RET_SM2_SIGN_FAILURE;

	#ifdef SM2_FLOW_CONTROL
		if (sm2_flow_flag != (189*2 + 11))
		{
			return RET_SM2_VERIFY_FAILURE;
		}
		sm2_flow_flag *= sm2_step;
		sm2_flow_flag += 485;
		sm2_step = 4;
	#endif
	
#ifdef SM2_DEBUG
 	MyPrintf("\n ecc_pmul_calc:%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);	
	MyPrintf("c1:\n");
	MyPrintf("x:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",c1.x[i]);	MyPrintf("\n");
	MyPrintf("y:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",c1.y[i]);	MyPrintf("\n");
#endif	

	c2_p.x= c2.x;
	c2_p.y= c2.y;
	pa.x = key->x;
	pa.y = key->y;
	ret = ecc_pmul(&c2_p,&pa, t, &para_t,&security_t,NULL,0);
	if(ret != RET_ECC_POINT_SUCCESS)
		return RET_SM2_SIGN_FAILURE;

	#ifdef SM2_FLOW_CONTROL
		if (sm2_flow_flag != ((189*2 + 11)*3 + 485))
		{
			return RET_SM2_VERIFY_FAILURE;
		}
		sm2_flow_flag *= sm2_step;
		sm2_flow_flag += 941;
		sm2_step = 5;
	#endif
#ifdef SM2_DEBUG
 	MyPrintf("\n ecc_pmul_calc:%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);	
	MyPrintf("c2:\n");
	MyPrintf("x:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",c2.x[i]);	MyPrintf("\n");
	MyPrintf("y:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",c2.y[i]);	MyPrintf("\n");
#endif	

	j2.x = c2_p.x;
	j2.y = c2_p.y;
	j2.z = z2;
	mem_rollcpy(j2.z, ( unsigned int *)CONST_LONG_ONE, para_t.len_words,GetTRNGData());
	j1.x = c1_p.x;
	j1.y = c1_p.y;
	j1.z = z1;

	if (config <= ECC_P256)
	{
		ret = ecc_padd_ja(&j1,&j2, &c1_p, &para_t);
		if(ret != RET_ECC_POINT_SUCCESS)
		{
			return RET_SM2_SIGN_FAILURE;
		}
	}
	else
	{
		ret = mem_rollcmp(c1.x, c2.x, para_t.len_words,GetTRNGData());
		if (ret == CMPOK)
		{
			ret = mem_rollcmp(c1.y, c2.x, para_t.len_words,GetTRNGData());
		}

		if (ret == CMPOK)
		{
			sm2_bin_padd_2(&c1_p, &j1,&j2, &para_t);
		}
		else
		{
			sm2_bin_padd_1(&c1_p, &j1,&j2, &para_t);
		}
	}

	#ifdef SM2_FLOW_CONTROL
		if (sm2_flow_flag != (((189*2 + 11)*3 + 485) * 4 +941))
		{
			return RET_SM2_VERIFY_FAILURE;
		}
		sm2_flow_flag *= sm2_step;
		sm2_flow_flag += 5469;
		sm2_step = 6;
	#endif
	
#ifdef SM2_DEBUG
 	MyPrintf("\n ecc_pmul_calc:%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);	
	MyPrintf("x1:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",c1.x[i]);	MyPrintf("\n");
	MyPrintf("y1:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",c1.y[i]);	MyPrintf("\n");
#endif	

	calc_modadd_1(t,e,c1_p.x, para_t.n, (para_t.len_words > 8)? para_t.len_words : 8);
	#ifdef SM2_FLOW_CONTROL
		if (sm2_flow_flag != ((((189*2 + 11)*3 + 485) * 4 +941)*5 +5469))
		{
			return RET_SM2_VERIFY_FAILURE;
		}
		sm2_flow_flag *= sm2_step;
		sm2_flow_flag += 3;
	#endif
	
#ifdef SM2_DEBUG
	MyPrintf("\n  t \n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",t[i]);	MyPrintf("\n");
#endif	
	
	if (CMPOK != mem_rollcmp((unsigned int *)(t),(unsigned int *)sign->r ,para_t.len_words,GetTRNGData()))
		return RET_SM2_VERIFY_FAILURE;
	else
	{
		#ifdef SM2_FLOW_CONTROL
			if (sm2_flow_flag != (((((189*2 + 11)*3 + 485) * 4 +941)*5 +5469)*6 +3))
			{
				return RET_SM2_VERIFY_FAILURE;
			}
		#endif
		return RET_SM2_VERIFY_SUCCESS;	
	}

}


uint32_t SM2_Enc(uint8_t *output, uint32_t *olen,
					 uint8_t *input, uint32_t ilen,
					 SM2_PublicKeyTypeDef *key,  SM2_EllipseParaTypeDef *para,
					rng_callback f_rng, void *p_rng,uint8_t config)
{
	uint32_t i,ret;

	uint32_t k[9]={0x49DD7B4F,0x18E5388D,0x5546D490,0x8AFA1742,0x3D957514,0x5B92FD6C,0x6ECFC2B9,0x4C62EEFD};

	uint32_t a_x[8]={0},a_y[8]={0};
	ecc_point_a a_temp;
	uint32_t key_bytes_len = 0;

	ecc_security security_t;
	SM2_PointTypeDef c1,pb;
	ecc_point_a c1_p,pb_p,key_p;
	ecc_para para_t;
	uint32_t c2[5]={0};
	uint8_t data_temp[84]={0};
	uint32_t p_c[9]={0},n_c[9]={0},n1_c[9]={0};
	uint32_t rand[4]={0};

	// security_t.mask=INT_MASK_CLOSE;
	// security_t.verify=EC_PARA_VERIFY_CLOSE;
	security_t.mask=INT_MASK_OPEN;
	security_t.verify=EC_PARA_VERIFY_OPEN;
	// para_t.p = para->p;
	// para_t.a = para->a;
	// para_t.b = para->b;
	// para_t.g.x = para->g.x;
	// para_t.g.y = para->g.y;
	// para_t.n = para->n;

	// para_t.p_c = p_c;
	// para_t.n_c = n_c;

	// para_t.len_bits = SM2_KEY_BITS;
	// para_t.len_words = SM2_KEY_WORDS;
	// para_t.a_type = !ECC_A_IS_NEGATIVE_3;
	// para_t.field = ECC_PRIME;

	// ecc_config(&para_t,ECC_B257);
	// calc_const_c(para_t.n_c, para_t.n,para_t.len_words);
	// calc_const_q(&para_t.n_q, para_t.n);

	init_para(&para_t, p_c, n_c, n1_c, para, ECC_P256,  !ECC_A_IS_NEGATIVE_3);

#ifdef BCTC
		for (i=0;i<9;i++)
		{
			k[i] = sm2_rand_val[i];
		}
#else
		for (i=0;i<8;i++)
		{
			k[i] = GetTRNGData();
		}
#endif

#ifdef SM2_DEBUG
	MyPrintf("para_t:\n");
	MyPrintf("para_t.p:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.p[i]);	MyPrintf("\n");
	MyPrintf("para_def.a:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.a[i]);	MyPrintf("\n");
	MyPrintf("para_def.b:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.b[i]);	MyPrintf("\n");
	MyPrintf("para_def.g.x:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.g.x[i]);	MyPrintf("\n");
	MyPrintf("para_def.g.y:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.g.y[i]);	MyPrintf("\n");
	MyPrintf("para_def.n:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.n[i]);	MyPrintf("\n");

	MyPrintf("para_def.p_c:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.p_c[i]);	MyPrintf("\n");
	MyPrintf("para_def.p_q:\n");
	for(i=0;i<1;i++)
		MyPrintf("%08x ",para_t.p_q);	MyPrintf("\n");
	MyPrintf("para_def.n_c:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.n_c[i]);	MyPrintf("\n");
	MyPrintf("para_def.n_q:\n");
	for(i=0;i<1;i++)
		MyPrintf("%08x ",para_t.n_q);	MyPrintf("\n");
	MyPrintf("K:\n");
	for(i=0;i<9;i++)
		MyPrintf("%08x ",k[i]);	MyPrintf("\n");
#endif

	c1_p.x= c1.x;
	c1_p.y= c1.y;
	
	ret = ecc_pmul(&c1_p,&(para_t.g), k,&para_t,&security_t,NULL,0);
	if(ret != RET_ECC_POINT_SUCCESS)
		return RET_SM2_ENC_FAILURE;
#ifdef SM2_DEBUG
 	MyPrintf("\n ecc_pmul_calc:%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);	
	MyPrintf("c1:\n");
	MyPrintf("x:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",c1.x[i]);	MyPrintf("\n");
	MyPrintf("y:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",c1.y[i]);	MyPrintf("\n");
#endif
	pb_p.x = pb.x;
	pb_p.y = pb.y;
	key_p.x = key->x;
	key_p.y = key->y;
	ret = ecc_pmul(&pb_p,&key_p, k,&para_t,&security_t,NULL,0);
	if(ret != RET_ECC_POINT_SUCCESS)
		return RET_SM2_ENC_FAILURE;
#ifdef SM2_DEBUG
 	MyPrintf("\n ecc_pmul_calc:%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);
	MyPrintf("x2:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",pb.x[i]);	MyPrintf("\n");
	MyPrintf("y2:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",pb.y[i]);	MyPrintf("\n");
#endif
	key_bytes_len = (para_t.len_bits + 7)/8;
	mem_rollcpy_r_char(data_temp,                (uint8_t *)pb.x,key_bytes_len,GetTRNGData());
	mem_rollcpy_r_char(data_temp + key_bytes_len,(uint8_t *)pb.y,key_bytes_len,GetTRNGData());

    ret = SM2_KDF(&output[key_bytes_len*2+1],ilen,data_temp,key_bytes_len*2);
#ifdef SM2_DEBUG
 	MyPrintf("\n SM2 KDF :%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);
	MyPrintf("t:\n");
	for(i=0;i<ilen;i++)
		MyPrintf("%02x ",output[i + key_bytes_len*2+1]);	MyPrintf("\n");
#endif

	for(i=0;i<ilen;i++)
		output[i+key_bytes_len*2+1] = input[i] ^ (output[i+key_bytes_len*2+1]) ;//c2 len

#ifdef SM2_DEBUG
	MyPrintf("input:\n");
	for(i=0;i<ilen;i++)
		MyPrintf("%02x ",input[i]);	MyPrintf("\n");
	MyPrintf("c2:\n");
	for(i=0;i<ilen;i++)
		MyPrintf("%02x ",output[i+key_bytes_len*2+1]);	MyPrintf("\n");
#endif
	//x2
#ifdef SM2_DEBUG
	MyPrintf("pb.x:\n");
#endif
	for(i = 0;i<key_bytes_len;i++)
	{
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*((uint8_t *)(pb.x)+key_bytes_len-i-1));
		#endif
		SM3_BYTE(NULL,*((uint8_t *)(pb.x)+key_bytes_len-i-1),i,0);
	}
	//Message
#ifdef SM2_DEBUG
	MyPrintf("\n message:\n");
#endif
	for(i = 0;i < ilen;i++)
	{
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",input[i]);
		#endif
		SM3_BYTE(NULL,input[i],key_bytes_len + i,0);
	}

	//Y2
#ifdef SM2_DEBUG
	MyPrintf("\n pb.y:\n");
#endif
	for(i = 0; i < key_bytes_len; i++)
	{
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*((uint8_t *)(pb.y)+key_bytes_len-i-1));
		#endif
		if(i == key_bytes_len - 1)
		{
			SM3_BYTE(output+key_bytes_len*2+1+ilen,*((uint8_t *)(pb.y)+key_bytes_len-i-1),key_bytes_len + ilen + i,1);
		}
		else
		{
			SM3_BYTE(NULL,*((uint8_t *)(pb.y)+key_bytes_len-i-1),key_bytes_len + ilen + i,0);
		}
	}
#ifdef SM2_DEBUG
	MyPrintf("\n c3:\n");
	for(i=0;i<32;i++)
		MyPrintf("%02x ",output[i+key_bytes_len*2+1+ilen]);	MyPrintf("\n");
#endif

	output[0] = 0x04;		//c1 len65
	mem_rollcpy_r_char(output+1,              (uint8_t*)c1.x[0],key_bytes_len, GetTRNGData());
	mem_rollcpy_r_char(output+1+key_bytes_len,(uint8_t*)c1.y[0],key_bytes_len, GetTRNGData());
	*olen = 1 + key_bytes_len * 2 + ilen + 32;
	return RET_SM2_ENC_SUCCESS;

CALC_SM2_ENC_FAILURE:
	memset(output,0,1 + key_bytes_len * 2 + ilen + 32);
	return RET_SM2_ENC_FAILURE;
}


uint32_t SM2_Dec(uint8_t *output, uint32_t *olen,
					 uint8_t *input, uint32_t ilen,
					 SM2_PrivateKeyTypeDef *key,  SM2_EllipseParaTypeDef *para,
					rng_callback f_rng, void *p_rng,uint8_t config)
{
	uint32_t i,ret;
	uint32_t k[9]={0};
	uint8_t data_temp[84]={0};
	uint32_t c2[5]={0} ,u[8]={0},c3[8]={0};
	uint32_t key_bytes_len = 0;
	ecc_para para_t;
	SM2_PointTypeDef c1,pb;
	ecc_point_a c1_p,pb_p;

	uint32_t p_c[9]={0},n_c[9]={0},n1_c[9]={0};
	ecc_security security_t;
	// security_t.mask=INT_MASK_CLOSE;
	// security_t.verify=EC_PARA_VERIFY_CLOSE;
	security_t.mask=INT_MASK_OPEN;
	security_t.verify=EC_PARA_VERIFY_OPEN;

	// para_t.p = para->p;
	// para_t.a = para->a;
	// para_t.b = para->b;
	// para_t.g.x = para->g.x;
	// para_t.g.y = para->g.y;
	// para_t.n = para->n;

	// para_t.p_c = p_c;
	// para_t.n_c = n_c;

	// para_t.len_bits = SM2_KEY_BITS;
	// para_t.len_words = SM2_KEY_WORDS;
	// para_t.a_type = !ECC_A_IS_NEGATIVE_3;
	// para_t.field = ECC_PRIME;

	// ecc_config(&para_t,ECC_B257);
	// calc_const_c(para_t.n_c, para_t.n,para_t.len_words);
	// calc_const_q(&para_t.n_q, para_t.n);

	init_para(&para_t, p_c, n_c, n1_c, para, ECC_P256,  !ECC_A_IS_NEGATIVE_3);

	key_bytes_len = (para_t.len_bits + 7)/8;
	ilen = ilen - 1 - key_bytes_len * 2 - 32;
#ifdef BCTC
		for (i=0;i<9;i++)
		{
			k[i] = sm2_rand_val[i];
		}
#else
		for (i=0;i<8;i++)
		{
			k[i] = GetTRNGData();
		}
#endif
#ifdef SM2_DEBUG
	MyPrintf("para_t:\n");
	MyPrintf("para_t.p:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.p[i]);	MyPrintf("\n");
	MyPrintf("para_def.a:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.a[i]);	MyPrintf("\n");
	MyPrintf("para_def.b:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.b[i]);	MyPrintf("\n");
	MyPrintf("para_def.g.x:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.g.x[i]);	MyPrintf("\n");
	MyPrintf("para_def.g.y:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.g.y[i]);	MyPrintf("\n");
	MyPrintf("para_def.n:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.n[i]);	MyPrintf("\n");

	MyPrintf("para_def.p_c:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.p_c[i]);	MyPrintf("\n");
	MyPrintf("para_def.p_q:\n");
	for(i=0;i<1;i++)
		MyPrintf("%08x ",para_t.p_q);	MyPrintf("\n");
	MyPrintf("para_def.n_c:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",para_t.n_c[i]);	MyPrintf("\n");
	MyPrintf("para_def.n_q:\n");
	for(i=0;i<1;i++)
		MyPrintf("%08x ",para_t.n_q);	MyPrintf("\n");
#endif
	pb_p.x= pb.x;
	pb_p.y= pb.y;

	c1_p.x= c1.x;
	c1_p.y= c1.y;

	mem_set((c1_p.x),0x00000000,9);
	mem_set((c1_p.y),0x00000000,9);
	mem_rollcpy_r_char((uint8_t *)(c1_p.x),input + 1,                key_bytes_len, GetTRNGData());
	mem_rollcpy_r_char((uint8_t *)(c1_p.y),input + 1 + key_bytes_len,key_bytes_len, GetTRNGData());

#ifdef SM2_DEBUG
	MyPrintf("c1:\n");
	MyPrintf("x:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",c1.x[i]);	MyPrintf("\n");
	MyPrintf("y:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",c1.y[i]);	MyPrintf("\n");
	MyPrintf("db:\n");
	MyPrintf("x:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",key->d[i]);	MyPrintf("\n");
#endif

	ret = ecc_pmul(&pb_p,&c1_p, key->d,&para_t,&security_t,NULL,0);
	if(ret != RET_ECC_POINT_SUCCESS)
		return RET_SM2_ENC_FAILURE;
 #ifdef SM2_DEBUG
	MyPrintf("\n ecc_pmul_calc:%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);	
	MyPrintf("pb:\n");
	MyPrintf("x:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",pb.x[i]);	MyPrintf("\n");
	MyPrintf("y:\n");
	for(i=0;i<para_t.len_words;i++)
		MyPrintf("%08x ",pb.y[i]);	MyPrintf("\n");
#endif
	mem_rollcpy_r_char(data_temp,                (uint8_t *)pb.x,key_bytes_len,GetTRNGData());
	mem_rollcpy_r_char(data_temp + key_bytes_len,(uint8_t *)pb.y,key_bytes_len,GetTRNGData());
	ret = SM2_KDF(output ,ilen,data_temp, key_bytes_len * 2);
#ifdef SM2_DEBUG
 	MyPrintf("\n ecc_pmul_calc:%c%c%c%c\n",ret,ret>>8,ret>>16,ret>>24);	
	MyPrintf("t:\n");
	for(i=0;i<ilen;i++)
		MyPrintf("%02x ",  output[i]);	MyPrintf("\n");
#endif
	for(i=0;i<ilen;i++)
		output[i] = input[i+1+key_bytes_len*2] ^ output[i];

#ifdef SM2_DEBUG
	MyPrintf("output:\n");
	for(i=0;i<ilen;i++)
		MyPrintf("%02x ",output[i]);	MyPrintf("\n");
#endif
	//x2
#ifdef SM2_DEBUG
	MyPrintf("pb.x:\n");
#endif
	for(i = 0;i<key_bytes_len;i++)
	{
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*((uint8_t *)(pb.x)+key_bytes_len-i-1));
		#endif
		SM3_BYTE(NULL,*((uint8_t *)(pb.x)+key_bytes_len-i-1),i,0);
	}
	//Message
#ifdef SM2_DEBUG
	MyPrintf("\n message:\n");
#endif
	for(i = 0;i < ilen;i++)
	{
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",input[i]);
		#endif
		SM3_BYTE(NULL,output[i],key_bytes_len + i,0);
	}

	//Y2
#ifdef SM2_DEBUG
	MyPrintf("\n pb.y:\n");
#endif
	for(i = 0; i < key_bytes_len; i++)
	{
		#ifdef SM2_DEBUG
			MyPrintf("%02x ",*((uint8_t *)(pb.y)+key_bytes_len-i-1));
		#endif
		if(i == key_bytes_len - 1)
		{
			SM3_BYTE((uint8_t *)u,*((uint8_t *)(pb.y)+key_bytes_len-i-1),key_bytes_len + ilen + i,1);
		}
		else
		{
			SM3_BYTE(NULL,*((uint8_t *)(pb.y)+key_bytes_len-i-1),key_bytes_len + ilen + i,0);
		}
	}
#ifdef SM2_DEBUG
	MyPrintf("\n u:\n");
	for(i=0;i<32;i++)
		MyPrintf("%02x ",((uint8_t*)u)[i]);	MyPrintf("\n");
#endif

	memcpy((uint8_t *)c3,input + key_bytes_len * 2  + 1 + ilen,32);
#ifdef SM2_DEBUG
	MyPrintf("c3:\n");
	for(i=0;i<32;i++)
		MyPrintf("%02x ",((uint8_t*)c3)[i]);	MyPrintf("\n");
#endif
	if (EQUAL != mem_cmp((volatile unsigned int *)(c3),(volatile unsigned int *)u ,8))
	{
		return RET_SM2_DEC_FAILURE;
	}
	else
	{
		*olen = ilen;
		return RET_SM2_DEC_SUCCESS;
	}
}

/**
  * @method	SM2_Genkey
  * @brief	SM2 密钥生成函数，用于生成 SM2 密钥
  * @param	key   : SM2 私钥（输出参数）
  * @param	para  : 椭圆曲线参数（输入参数）
  * @param	f_rng : 随机数函数（输入参数）
  * @param	p_rng : 随机数函数参数（输入参数）
  * @retval RET_ECC_KEY_GEN_SUCCESS or RET_SM2_KEY_GEN_ERROR
  */
uint32_t SM2_Genkey(SM2_PrivateKeyTypeDef *key, const SM2_EllipseParaTypeDef *para,
                    rng_callback f_rng, void *p_rng, uint8_t config)
{
		uint32_t i = 0;
		uint32_t rand_key[9]={0};
		ecc_para para_t;
		uint32_t p_c[9]={0},n_c[9]={0},n1_c[9]={0};
		uint32_t value = 0;
		ecc_point_a e;

		ecc_security security_t;
		security_t.mask=INT_MASK_CLOSE;
		security_t.verify=EC_PARA_VERIFY_CLOSE;

		#ifdef BCTC
				for (i=0;i<9;i++)
				{
					rand_key[i] = sm2_rand_val[i];
				}
		#else
				(*f_rng)((uint8_t *)rand_key ,33,p_rng);
		#endif

		init_para(&para_t, p_c, n_c, n1_c, (SM2_EllipseParaTypeDef *)para, config,!ECC_A_IS_NEGATIVE_3);

		#ifdef SM2_DEBUG
			MyPrintf("rand_key:\n");
			for(i=0;i<para_t.len_words;i++)
				MyPrintf("%08x ",rand_key[i]);	MyPrintf("\n");
		#endif

		calc_div(NULL,key->d,rand_key,para_t.n,para_t.len_words,para_t.len_words);//d=random%n
//		if (para_t.field==ECC_PRIME)
//			key->d[para_t.len_words-1] |= 0x80000000;                           //密钥最高位置1
//		else
//			key->d[para_t.len_words-1] |= 1<<((para_t.len_bits & 0x1f)-1);

		e.x= key->e.x;
		e.y= key->e.y;
		value = ecc_pmul(&e, &(para_t.g), key->d, &para_t, &security_t, NULL,0);

		#ifdef SM2_DEBUG
			MyPrintf("para_def.g.x:\n");
			for(i=0;i<para_t.len_words;i++)
				MyPrintf("%08x ",para_t.g.x[i]);	MyPrintf("\n");
			MyPrintf("para_def.g.y:\n");
			for(i=0;i<para_t.len_words;i++)
				MyPrintf("%08x ",para_t.g.y[i]);	MyPrintf("\n");

			MyPrintf("d:\n");
			for(i=0;i<para_t.len_words;i++)
				MyPrintf("%08x ",key->d[i]);	MyPrintf("\n");
			MyPrintf("e.x:\n");
			for(i=0;i<para_t.len_words;i++)
				MyPrintf("%08x ",key->e.x[i]);	MyPrintf("\n");
			MyPrintf("e.y:\n");
			for(i=0;i<para_t.len_words;i++)
				MyPrintf("%08x ",key->e.y[i]);	MyPrintf("\n");
		#endif

		if (value!=RET_ECC_POINT_SUCCESS)
			return value;


		return 	RET_ECC_KEY_GENERATION_SUCCESS;


}


